"use strict";
globalThis["webpackHotUpdateanima_sample_storybook"]("main",{

/***/ "../my-addon/dist/addDecorators.js":
/*!*****************************************!*\
  !*** ../my-addon/dist/addDecorators.js ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decorators": () => (/* binding */ decorators)
/* harmony export */ });
/* harmony import */ var _decorators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./decorators */ "../my-addon/dist/decorators/index.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


var decorators = [_decorators__WEBPACK_IMPORTED_MODULE_0__.withHTML];


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/addDecorators.js-generated-config-entry.js":
/*!*******************************************************************!*\
  !*** ../my-addon/dist/addDecorators.js-generated-config-entry.js ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@storybook/client-api */ "./node_modules/@storybook/client-api/dist/esm/ClientApi.js");
/* harmony import */ var _home_moez_anima_sample_storybook_node_modules_storybook_client_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@storybook/client-logger */ "./node_modules/@storybook/client-logger/dist/esm/index.js");
/* harmony import */ var _home_moez_my_addon_dist_addDecorators_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../my-addon/dist/addDecorators.js */ "../my-addon/dist/addDecorators.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* eslint-disable import/no-unresolved */



Object.keys(_home_moez_my_addon_dist_addDecorators_js__WEBPACK_IMPORTED_MODULE_0__).forEach(function (key) {
  var value = _home_moez_my_addon_dist_addDecorators_js__WEBPACK_IMPORTED_MODULE_0__[key];

  switch (key) {
    case 'args':
    case 'argTypes':
      {
        return _home_moez_anima_sample_storybook_node_modules_storybook_client_logger__WEBPACK_IMPORTED_MODULE_1__.logger.warn('Invalid args/argTypes in config, ignoring.', JSON.stringify(value));
      }

    case 'decorators':
      {
        return value.forEach(function (decorator) {
          return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addDecorator)(decorator, false);
        });
      }

    case 'loaders':
      {
        return value.forEach(function (loader) {
          return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addLoader)(loader, false);
        });
      }

    case 'parameters':
      {
        return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addParameters)(_objectSpread({}, value), false);
      }

    case 'argTypesEnhancers':
      {
        return value.forEach(function (enhancer) {
          return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addArgTypesEnhancer)(enhancer);
        });
      }

    case 'argsEnhancers':
      {
        return value.forEach(function (enhancer) {
          return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addArgsEnhancer)(enhancer);
        });
      }

    case 'render':
      {
        return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.setGlobalRender)(value);
      }

    case 'globals':
    case 'globalTypes':
      {
        var v = {};
        v[key] = value;
        return (0,_home_moez_anima_sample_storybook_node_modules_storybook_client_api__WEBPACK_IMPORTED_MODULE_2__.addParameters)(v, false);
      }

    case '__namedExportsOrder':
    case 'decorateStory':
    case 'renderToDOM':
      {
        return null; // This key is not handled directly in v6 mode.
      }

    default:
      {
        // eslint-disable-next-line prefer-template
        return console.log(key + ' was not supported :( !');
      }
  }
});

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/components/alert.js":
/*!********************************************!*\
  !*** ../my-addon/dist/components/alert.js ***!
  \********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createAlert": () => (/* binding */ createAlert)
/* harmony export */ });
/* harmony import */ var _storybook_theming__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @storybook/theming */ "./node_modules/@emotion/core/dist/core.browser.esm.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils */ "../my-addon/dist/utils/index.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var __makeTemplateObject = (undefined && undefined.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};


var createAlert = function (text) {
    var htmlTemplate = "\n  <div style=\"".concat((0,_storybook_theming__WEBPACK_IMPORTED_MODULE_1__.css)(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n      position: fixed;\n      top: 0;\n      left: 0;\n      right: 0;\n      width: 100%;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      padding-top: 12px;\n    "], ["\n      position: fixed;\n      top: 0;\n      left: 0;\n      right: 0;\n      width: 100%;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      padding-top: 12px;\n    "]))).styles, "\">\n  <div style=\"").concat((0,_storybook_theming__WEBPACK_IMPORTED_MODULE_1__.css)(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n      background: #222;\n      border-radius: 5px;\n      opacity: 0;\n      transition: opacity 0.15s linear;\n      box-shadow: 0 5px 17px #0003, 0 2px 7px #00000026,\n        inset 0 0 0 1px var(--bg-overlay-inner-outline),\n        0 0 0 1px var(--bg-overlay-outline);\n    "], ["\n      background: #222;\n      border-radius: 5px;\n      opacity: 0;\n      transition: opacity 0.15s linear;\n      box-shadow: 0 5px 17px #0003, 0 2px 7px #00000026,\n        inset 0 0 0 1px var(--bg-overlay-inner-outline),\n        0 0 0 1px var(--bg-overlay-outline);\n    "]))).styles, "\">\n    <div style=\"").concat((0,_storybook_theming__WEBPACK_IMPORTED_MODULE_1__.css)(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n        position: relative;\n        padding: 6px 16px;\n      "], ["\n        position: relative;\n        padding: 6px 16px;\n      "]))).styles, "\">\n      <div style=\"").concat((0,_storybook_theming__WEBPACK_IMPORTED_MODULE_1__.css)(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n          display: flex;\n          align-items: center;\n        "], ["\n          display: flex;\n          align-items: center;\n        "]))).styles, "\">\n      <svg\n        style=\"margin-right: 10px;\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n        fill=\"none\"\n        width=\"18\"\n        height=\"18\"\n        viewBox=\"0 0 32 32\"\n      >\n        <rect width=\"32\" height=\"32\" fill=\"#3B3B3B\" rx=\"4\" />\n        <path\n          fill=\"#FF6250\"\n          d=\"M7.1287 6H24.353a.1262.1262 0 0 1 .1088.0586.1266.1266 0 0 1 .0072.1234 19.319 19.319 0 0 1-6.4955 7.4335c-4.4781 3.0214-8.9875 3.3334-10.8435 3.35a.1261.1261 0 0 1-.12-.0779.1282.1282 0 0 1-.01-.0494V6.1273A.1274.1274 0 0 1 7.1287 6Z\"\n        />\n        <path\n          fill=\"#FFDF90\"\n          d=\"M10.8461 25.9999c2.1241 0 3.846-1.7219 3.846-3.846 0-2.1242-1.7219-3.8461-3.846-3.8461C8.7219 18.3078 7 20.0297 7 22.1539c0 2.1241 1.722 3.846 3.8461 3.846Z\"\n        />\n        <path\n          fill=\"#36F\"\n          d=\"M18.708 25.7722c-1.088-.4153-1.6667-1.6127-1.298-2.6727l2.9034-8.2855c.372-1.06 1.5554-1.582 2.6434-1.1667 1.088.4161 1.6667 1.6127 1.298 2.6734l-2.9034 8.2855c-.372 1.06-1.5553 1.5827-2.6434 1.166Z\"\n        />\n       </svg>\n        <span style=\"").concat((0,_storybook_theming__WEBPACK_IMPORTED_MODULE_1__.css)(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n            line-height: 24px;\n            color: #fff;\n            font-size: 13px;\n            font-family: Mulish, sans-serif;\n          "], ["\n            line-height: 24px;\n            color: #fff;\n            font-size: 13px;\n            font-family: Mulish, sans-serif;\n          "]))).styles, "\" >").concat(text, "</span>\n      </div>\n    </div>\n  </div>\n  </div>");
    return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.createElementFromHTML)(htmlTemplate);
};
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5;


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/constants.js":
/*!*************************************!*\
  !*** ../my-addon/dist/constants.js ***!
  \*************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "API_URL": () => (/* binding */ API_URL),
/* harmony export */   "EVENT_CODE_RECEIVED": () => (/* binding */ EVENT_CODE_RECEIVED),
/* harmony export */   "IFRAME_RENDERER_CLICK": () => (/* binding */ IFRAME_RENDERER_CLICK),
/* harmony export */   "STORYBOOK_ANIMA_TOKEN": () => (/* binding */ STORYBOOK_ANIMA_TOKEN)
/* harmony export */ });
/* unused harmony exports PARAM_KEY, EXPORT_START, EXPORT_END, EXPORT_SINGLE_STORY, EXPORT_ALL_STORIES, EXPORT_PROGRESS, TOGGLE_EXPORT_STATUS, ADDON_ID */
/* provided dependency */ var process = __webpack_require__(/*! ./node_modules/process/browser.js */ "./node_modules/process/browser.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var API_URL = localStorage.getItem("api_url") || "https://api.animaapp.com";
var PARAM_KEY = "export-stories";
var EVENT_CODE_RECEIVED = "EVENT_CODE_RECEIVED";
var IFRAME_RENDERER_CLICK = "IFRAME_RENDERER_CLICK";
var EXPORT_START = "EXPORT_START";
var EXPORT_END = "EXPORT_END";
var EXPORT_SINGLE_STORY = "EXPORT_SINGLE_STORY";
var EXPORT_ALL_STORIES = "EXPORT_ALL_STORIES";
var EXPORT_PROGRESS = "EXPORT_PROGRESS";
var TOGGLE_EXPORT_STATUS = "TOGGLE_EXPORT_STATUS";
var ADDON_ID = "storybook/anima";
var STORYBOOK_ANIMA_TOKEN = process.env.STORYBOOK_ANIMA_TOKEN;


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/decorators/index.js":
/*!********************************************!*\
  !*** ../my-addon/dist/decorators/index.js ***!
  \********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "withHTML": () => (/* reexport safe */ _withHTML__WEBPACK_IMPORTED_MODULE_0__.withHTML)
/* harmony export */ });
/* harmony import */ var _withHTML__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./withHTML */ "../my-addon/dist/decorators/withHTML.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");




const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/decorators/withHTML.js":
/*!***********************************************!*\
  !*** ../my-addon/dist/decorators/withHTML.js ***!
  \***********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "withHTML": () => (/* binding */ withHTML)
/* harmony export */ });
/* harmony import */ var _storybook_addons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @storybook/addons */ "./node_modules/@storybook/addons/dist/esm/make-decorator.js");
/* harmony import */ var _storybook_addons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @storybook/addons */ "./node_modules/@storybook/addons/dist/esm/index.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "../my-addon/dist/constants.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "../my-addon/dist/utils/index.js");
/* module decorator */ module = __webpack_require__.hmd(module);
/* provided dependency */ var process = __webpack_require__(/*! ./node_modules/process/browser.js */ "./node_modules/process/browser.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");




var listener;
var withHTML = (0,_storybook_addons__WEBPACK_IMPORTED_MODULE_2__.makeDecorator)({
    name: "withHTML",
    parameterName: "html",
    skipIfNoParametersOrOptions: false,
    wrapper: function (storyFn, context, _a) {
        var _b = _a.parameters, parameters = _b === void 0 ? {} : _b;
        process.nextTick(function () {
            if (listener) {
                document.removeEventListener("click", listener);
            }
            var channel = _storybook_addons__WEBPACK_IMPORTED_MODULE_3__.addons.getChannel();
            var rootSelector = parameters.root || "#root";
            var root = document.querySelector(rootSelector);
            var css = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.extractCSS)();
            var html = root ? root.innerHTML : "".concat(rootSelector, " not found.");
            if (parameters.removeEmptyComments) {
                html = html.replace(/<!--\s*-->/g, "");
            }
            listener = function () {
                channel.emit(_constants__WEBPACK_IMPORTED_MODULE_0__.IFRAME_RENDERER_CLICK);
            };
            document.addEventListener("click", listener);
            var width = 0, height = 0;
            if (root) {
                var rootClone = root.cloneNode(true);
                rootClone.style.width = "fit-content";
                document.body.appendChild(rootClone);
                var rootRect = rootClone.getBoundingClientRect();
                width = rootRect.width;
                height = rootRect.height;
                if (rootClone.childNodes.length == 1) {
                    var rect = rootClone.firstElementChild.getBoundingClientRect();
                    width = rect.width;
                    height = rect.height;
                }
                rootClone.remove();
            }
            channel.emit(_constants__WEBPACK_IMPORTED_MODULE_0__.EVENT_CODE_RECEIVED, {
                html: html,
                css: css,
                width: width,
                height: height,
                options: parameters,
            });
        });
        return storyFn(context);
    },
});
if (module && module.hot && module.hot.decline) {
    module.hot.decline();
}


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/utils/api.js":
/*!*************************************!*\
  !*** ../my-addon/dist/utils/api.js ***!
  \*************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "extractCSS": () => (/* binding */ extractCSS)
/* harmony export */ });
/* unused harmony exports authenticate, getStorybookToken, updateTeamExportStatus, createStoryRequest, getStoryNameFromArgs */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "../my-addon/dist/constants.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers */ "../my-addon/dist/utils/helpers.js");
/* harmony import */ var pako__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! pako */ "../my-addon/node_modules/pako/dist/pako.esm.mjs");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};



var authenticate = function (storybookToken) { return __awaiter(void 0, void 0, void 0, function () {
    var errorRes, res, data, error_1;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                errorRes = { isAuthenticated: false, data: {} };
                if (!storybookToken)
                    return [2 /*return*/, errorRes];
                _a.label = 1;
            case 1:
                _a.trys.push([1, 5, , 6]);
                return [4 /*yield*/, fetch("".concat(_constants__WEBPACK_IMPORTED_MODULE_0__.API_URL, "/storybook_token/validate"), {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({ storybook_auth_token: storybookToken }),
                    })];
            case 2:
                res = _a.sent();
                if (!(res.status === 200)) return [3 /*break*/, 4];
                return [4 /*yield*/, res.json()];
            case 3:
                data = _a.sent();
                return [2 /*return*/, { isAuthenticated: true, data: data }];
            case 4: return [2 /*return*/, errorRes];
            case 5:
                error_1 = _a.sent();
                console.log(error_1);
                return [2 /*return*/, errorRes];
            case 6: return [2 /*return*/];
        }
    });
}); };
var getStorybookToken = function () {
    var params = new URLSearchParams(window.location.search);
    var tokenFromUrl = params.get("anima_t");
    if (tokenFromUrl) {
        localStorage.setItem("anima_t", tokenFromUrl);
        return tokenFromUrl;
    }
    var tokenFromLocalStorage = localStorage.getItem("anima_t");
    if (tokenFromLocalStorage) {
        return tokenFromLocalStorage;
    }
    return _constants__WEBPACK_IMPORTED_MODULE_0__.STORYBOOK_ANIMA_TOKEN;
};
var updateTeamExportStatus = function (value) {
    var storybookToken = getStorybookToken();
    if (!storybookToken)
        return;
    fetch("".concat(_constants__WEBPACK_IMPORTED_MODULE_0__.API_URL, "/teams/update_export_status"), {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            is_storybook_exporting: value,
            storybook_auth_token: storybookToken,
        }),
    });
};
var createStoryRequest = function (args) { return __awaiter(void 0, void 0, void 0, function () {
    var storybookToken, fingerprint, CSS, HTML, height, name, width, defaultCSS, defaultHTML, storybookId, isSample, gzippedBody;
    return __generator(this, function (_a) {
        storybookToken = args.storybookToken, fingerprint = args.fingerprint, CSS = args.CSS, HTML = args.HTML, height = args.height, name = args.name, width = args.width, defaultCSS = args.defaultCSS, defaultHTML = args.defaultHTML, storybookId = args.storybookId, isSample = args.isSample;
        if (!storybookToken)
            return [2 /*return*/, Promise.reject("No token")];
        gzippedBody = (0,pako__WEBPACK_IMPORTED_MODULE_2__.gzip)(JSON.stringify({
            html: HTML,
            css: CSS,
            fingerprint: fingerprint,
            width: width,
            height: height,
            name: name,
            storybookId: storybookId,
            storybook_auth_token: storybookToken,
            default_css: defaultCSS,
            default_html: defaultHTML,
            with_variants: true,
            is_sample: isSample,
        }));
        return [2 /*return*/, fetch("".concat(_constants__WEBPACK_IMPORTED_MODULE_0__.API_URL, "/stories"), {
                method: "POST",
                headers: {
                    storybook_auth_token: storybookToken,
                    "Content-Type": "application/json",
                    "Content-Encoding": "gzip",
                },
                body: gzippedBody,
            })];
    });
}); };
var extractCSS = function () {
    return Array.from(document.querySelectorAll("style"))
        .flatMap(function (_a) {
        var sheet = _a.sheet;
        return __spreadArray([], sheet.cssRules, true).map(function (rule) {
            var selector = (rule === null || rule === void 0 ? void 0 : rule.selectorText) || (rule === null || rule === void 0 ? void 0 : rule.name);
            if ([".sb-", "sb-", ":not(.sb"].some(function (e) { return selector === null || selector === void 0 ? void 0 : selector.startsWith(e); }))
                return "";
            return rule.cssText;
        });
    })
        .join(" ")
        .replace(/\\n/g, " ")
        .trim();
};
var getStoryNameFromArgs = function (storyName, args) {
    var defaultName = (0,_helpers__WEBPACK_IMPORTED_MODULE_1__.capitalize)(storyName);
    var name = "".concat(defaultName);
    var addedArgs = [defaultName];
    var addArg = function (s) {
        if (addedArgs.includes(s))
            return;
        name += " / ".concat((0,_helpers__WEBPACK_IMPORTED_MODULE_1__.capitalize)(s));
        addedArgs.push(s);
    };
    var keys = Object.keys(args);
    for (var i = 0; i < keys.length; i++) {
        if (addedArgs.length > 5)
            break; // max of 5 args per name
        var key = keys[i];
        var value = args[key];
        if ((0,_helpers__WEBPACK_IMPORTED_MODULE_1__.isString)(value)) {
            addArg(value);
        }
        if ((0,_helpers__WEBPACK_IMPORTED_MODULE_1__.isBoolean)(value) && value) {
            addArg(key);
        }
    }
    return name;
};


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/utils/helpers.js":
/*!*****************************************!*\
  !*** ../my-addon/dist/utils/helpers.js ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isString": () => (/* binding */ isString),
/* harmony export */   "isBoolean": () => (/* binding */ isBoolean),
/* harmony export */   "capitalize": () => (/* binding */ capitalize),
/* harmony export */   "createElementFromHTML": () => (/* binding */ createElementFromHTML)
/* harmony export */ });
/* unused harmony exports notify, downloadAsJSON, escapeHtml, isDocsStory */
/* harmony import */ var _components_alert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/alert */ "../my-addon/dist/components/alert.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


var isString = function (value) {
    return Object.prototype.toString.call(value) === "[object String]";
};
var isBoolean = function (val) { return "boolean" === typeof val; };
var capitalize = function (s) {
    if (!isString(s))
        return "";
    return s.charAt(0).toUpperCase() + s.slice(1);
};
var createElementFromHTML = function (htmlString) {
    var div = document.createElement("div");
    div.innerHTML = htmlString.trim();
    return div.firstElementChild;
};
var notify = function (text) {
    var alertElement = (0,_components_alert__WEBPACK_IMPORTED_MODULE_0__.createAlert)(text);
    document.body.appendChild(alertElement);
    alertElement.firstElementChild.style.opacity = "1";
    setTimeout(function () {
        alertElement.firstElementChild.style.opacity = "0";
        requestAnimationFrame(function () {
            alertElement.remove();
        });
    }, 2500);
};
var downloadAsJSON = function (data) {
    var content = JSON.stringify(data, null, 2);
    var blob = new Blob([content], { type: "text/json" });
    var dataURI = "data:text/json;charset=utf-8,".concat(content);
    var URL = window.URL || window.webkitURL;
    var downloadURI = typeof URL.createObjectURL === "undefined"
        ? dataURI
        : URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.setAttribute("href", downloadURI);
    link.setAttribute("download", "fg-json.json");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};
// Source: https://stackoverflow.com/a/6234804/18342693
var escapeHtml = function (html) {
    return html
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
};
var isDocsStory = function (story) {
    var _a;
    return !!((_a = story.parameters) === null || _a === void 0 ? void 0 : _a.docsOnly);
};


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/utils/index.js":
/*!***************************************!*\
  !*** ../my-addon/dist/utils/index.js ***!
  \***************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "extractCSS": () => (/* reexport safe */ _api__WEBPACK_IMPORTED_MODULE_0__.extractCSS),
/* harmony export */   "createElementFromHTML": () => (/* reexport safe */ _helpers__WEBPACK_IMPORTED_MODULE_1__.createElementFromHTML)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api */ "../my-addon/dist/utils/api.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers */ "../my-addon/dist/utils/helpers.js");
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles */ "../my-addon/dist/utils/styles.js");
/* harmony import */ var _seed__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./seed */ "../my-addon/dist/utils/seed.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");







const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/utils/seed.js":
/*!**************************************!*\
  !*** ../my-addon/dist/utils/seed.js ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports choice, runSeed */
/* harmony import */ var lodash_fp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash/fp */ "../my-addon/node_modules/lodash/fp.js");
/* harmony import */ var lodash_fp__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_fp__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var object_hash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! object-hash */ "../my-addon/node_modules/object-hash/dist/object_hash.js");
/* harmony import */ var object_hash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(object_hash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var flat__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! flat */ "../my-addon/node_modules/flat/index.js");
/* harmony import */ var flat__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(flat__WEBPACK_IMPORTED_MODULE_2__);
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};



var xProduct = function (vals) {
    return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.reduce)(function (a, b) {
        return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.flatMap)(function (x) { return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.map)(function (y) { return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.concat)(x, [y]); })(b); })(a);
    })([[]])(vals);
};
var compile = function (data) {
    return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.find)(function (v) { return isChoice(v); }, (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.values)(data))
        ? data
        : (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.mapValues)(function (v) { return ((0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.isArray)(v) ? choice.apply(void 0, v) : v); }, data);
};
var isChoice = function (v) {
    return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.isArray)(v) && v.length === 2 && (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.first)(v) === "$choice$";
};
var choice = function () {
    var choices = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        choices[_i] = arguments[_i];
    }
    return ["$choice$", choices];
};
var nodeValue = function (node) { return (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.get)("1", node); };
var runSeed = function (seed) {
    var data = flat__WEBPACK_IMPORTED_MODULE_2___default()(seed(), { safe: true });
    var compiledData = compile(data);
    var fields = (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.keys)(compiledData);
    var rows = (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.map)(function (p) { return (0,flat__WEBPACK_IMPORTED_MODULE_2__.unflatten)((0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.fromPairs)((0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.zip)(fields, p))); }, xProduct((0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.map)(function (v) { return (isChoice(v) ? nodeValue(v) : [v]); }, (0,lodash_fp__WEBPACK_IMPORTED_MODULE_0__.values)(compiledData))));
    return rows.map(function (e) {
        return __assign(__assign({}, e), { hash: object_hash__WEBPACK_IMPORTED_MODULE_1___default()(e) });
    });
};



const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "../my-addon/dist/utils/styles.js":
/*!****************************************!*\
  !*** ../my-addon/dist/utils/styles.js ***!
  \****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export injectCustomStyles */
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./helpers */ "../my-addon/dist/utils/helpers.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");


var GLOBAL_STYLES = "\n\n.anima_export_banner {\n  position: fixed;\n  z-index: 998;\n  bottom: 20px;\n  right: 20px;\n  height: 65px;\n  min-Width: 200px;\n  box-shadow: inset 0px 0px 0px 2px #505050;\n  border-radius: 5px;\n  overflow: hidden;\n  font-family: Mulish, sans-serif;\n}\n\n.anima_export_banner_content {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  padding: 15px;\n  background-color:#3B3B3B;\n  color:#fff;\n}\n\n.anima_export_banner_progress {\n  position: absolute;\n  z-index: 999;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 3px;\n  overflow: hidden;\n  background: #6F6F6F;\n}\n\n.anima_export_banner_progress_inner {\n  background: #ff6250;\n  width: var(--width);\n  height: 100%;\n  transition: width 0.2s ease;\n  will-change: width;\n}\n\n.sb_popover_content{\n  background-color: #3B3B3B;\n  padding:10px 0;\n  border-radius:5px;\n  color:#fff;\n  font-family: Mulish, sans-serif;\n  font-size:14px;\n  overflow:hidden;\n}\n.sb_popover_list{\n  list-style:none;\n  padding:0;\n  margin:0;\n  display:flex;\n  flex-direction:column;\n}\n.sb_popover_list_item {\n  padding:5px 20px;\n  cursor:pointer;\n\n}\n.sb_popover_list_item:not(:last-child) {\n  margin-bottom:5px;\n}\n.sb_popover_list_item:hover {\n  color:#ff6250;\n}\n\n";
var injectCustomStyles = function () {
    var customFont = document.querySelector("#anima-custom-font");
    !customFont &&
        document.head.appendChild((0,_helpers__WEBPACK_IMPORTED_MODULE_0__.createElementFromHTML)("<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">")) &&
        document.head.appendChild((0,_helpers__WEBPACK_IMPORTED_MODULE_0__.createElementFromHTML)("<link  href=\"https://fonts.googleapis.com/css2?family=Mulish:wght@400;500;600;700&display=swap\" rel=\"stylesheet\">")) &&
        document.head.appendChild((0,_helpers__WEBPACK_IMPORTED_MODULE_0__.createElementFromHTML)("<style>.t{animation:3s cubic-bezier(.34,1.56,.64,1) 0s infinite normal forwards running t;transform-box:fill-box;transform-origin:0% 0%}@keyframes t{0%{transform:scale(0);opacity:0}3.33%{opacity:1}23.33%{transform:scale(1)}76.67%{opacity:1}80%{transform:scale(1)}93.33%{transform:scale(0);opacity:0}100%{transform:scale(0);opacity:0}}.c{animation:3s cubic-bezier(.34,1.56,.64,1) .5s infinite normal forwards running c;transform-box:fill-box;transform-origin:50% 50%}@keyframes c{0%{transform:scale(0);opacity:0}3.33%{opacity:1}23.33%{transform:scale(1)}76.67%{opacity:1}80%{transform:scale(1)}93.33%{transform:scale(0);opacity:0}100%{transform:scale(0);opacity:0}}.l{animation:3s cubic-bezier(.34,1.56,.64,1) .8s infinite normal forwards running l;transform-box:fill-box;transform-origin:50% 50%}@keyframes l{0%{transform:scale(0) rotateZ(-180deg);opacity:0}3.33%{opacity:1}23.33%{transform:scale(1)}50%{transform:rotateZ(0)}76.67%{opacity:1}80%{transform:scale(1)}93.33%{transform:scale(0);opacity:0}100%{transform:scale(0);opacity:0}}</style>")) &&
        document.head.appendChild((0,_helpers__WEBPACK_IMPORTED_MODULE_0__.createElementFromHTML)("<style>".concat(GLOBAL_STYLES, "</style>")));
};


const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

});
//# sourceMappingURL=main.a48379fa679036b30e3d.hot-update.js.map